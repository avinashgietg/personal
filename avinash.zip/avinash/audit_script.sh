#!/bin/sh

dbname="fi999"
username="dbmsowner"
psql $dbname $username << EOF
COPY (SELECT * FROM pg_user) TO '/tmp/users_audit.csv' DELIMITER ',' CSV HEADER;
\q
dbname1="fi9999"
username1="dbmsowner"
psql $dbname1 $username1 << EOF
COPY (SELECT * FROM pg_roles) TO '/tmp/roles_audit.csv' DELIMITER ',' CSV HEADER;
\q
dbname2="fi6292"
username2="dbmsowner"
psql $dbname2 $username2 << EOF
COPY (SELECT * FROM information_schema) TO '/tmp/schema_audit.csv' DELIMITER ',' CSV HEADER;
EOF




